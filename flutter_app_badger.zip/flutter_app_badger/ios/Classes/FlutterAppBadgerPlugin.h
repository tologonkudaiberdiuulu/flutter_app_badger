#import <Flutter/Flutter.h>

@interface FlutterAppBadgerPlugin : NSObject<FlutterPlugin>
@end
