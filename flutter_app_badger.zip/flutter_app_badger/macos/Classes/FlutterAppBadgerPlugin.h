#import <FlutterMacOS/FlutterMacOS.h>
#import <Foundation/Foundation.h>

@interface FlutterAppBadgerPlugin : NSObject <FlutterPlugin>
@end
